USE [ASPNETCRUD]
GO

INSERT INTO [dbo].[Person]([name],[city])VALUES('Bob','Bellevue') select SCOPE_IDENTITY() as id;
GO


