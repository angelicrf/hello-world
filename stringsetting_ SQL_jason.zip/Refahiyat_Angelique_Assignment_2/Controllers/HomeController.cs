﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Refahiyat_Angelique_Assignment_2.Models;
using Microsoft.AspNetCore.Mvc;
using Refahiyat_Angelique_Assignment_2.Models.DAL;
using Microsoft.Extensions.Configuration;


namespace Refahiyat_Angelique_Assignment_2.Controllers
{
    public class HomeController : Controller
    {

        private readonly IConfiguration configuration;
        public HomeController(IConfiguration config)
        {

            this.configuration = config;
        }
        public IActionResult Index()
        {
            return View();
        }

     
        [HttpPost]
        public ActionResult page2(Person person)
        {

            //ViewBag.myValue = uName;
            //string connStr = configuration.GetConnectionString("MyConnStr");
            DALPerson dp = new DALPerson(configuration);
            int uID = dp.addUser(person);

            person.UID = uID;

            return View(person);
        }
        
       
    }
}
