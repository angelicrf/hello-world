﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Refahiyat_Angelique_Assignment_2.Models;
using Microsoft.Extensions.Configuration;
using System.Data.SqlClient;

namespace Refahiyat_Angelique_Assignment_2.Models.DAL
{
    public class DALPerson
    {
        private IConfiguration configuration;
        public DALPerson(IConfiguration configuration)
        {
            this.configuration = configuration;
        }
        public int addUser(Person person)
        {
            string connStr = configuration.GetConnectionString("MyConnStr");
            SqlConnection conn = new SqlConnection(connStr);
            conn.Open();
            string quary = "INSERT INTO [dbo].[Person]([name],[city])VALUES(@pName,@pCity) select SCOPE_IDENTITY() as id;";
            SqlCommand cmd = new SqlCommand(quary, conn);
            cmd.Parameters.AddWithValue("@pName", person.UName);
            cmd.Parameters.AddWithValue("@pCity", person.UCity);

            SqlDataReader reader = cmd.ExecuteReader();
            reader.Read();
            int uID = Convert.ToInt32(reader[0].ToString());
            conn.Close();

            return uID;






        }
        

    }
}
