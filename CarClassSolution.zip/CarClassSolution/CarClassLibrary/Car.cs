﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CarClassLibrary
{
    public class Car
    {
        private int _Weight;
        private string _Color;
        public int Weight
        {
            get { return _Weight; }
            set { _Weight = value; }
        }

       //Another way to return weight is to create a new public int function to return weight and call it on main.
       //public int WeightDetails(int weight)
       // {
       //     _Weight = weight;
       //     return weight;
       // }
        public string Color
        {
            get { return _Color; }
            set { _Color = value; }
        }

        public string Details(string color)
        {
            _Color = color;
       
            return color;
        }
    }
}
