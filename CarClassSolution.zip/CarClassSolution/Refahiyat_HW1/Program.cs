﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Console;
using CarClassLibrary;

namespace Refahiyat_HW1
{
    class Program
    {
        static void Main(string[] args)
        {
            Car car1 = new Car();
            Car car2 = new Car();

            car1.Weight = 3000;
            car2.Weight = 4000;

            int carWeight1 = car1.Weight;
            int carWeight2 = car2.Weight;

            string carColor1 = car1.Details("Blue");
            string carColor2 = car2.Details("Red");

            //int carWeight_1 = car1.WeightDetails(3000);
            //int carWeight_2 = car2.WeightDetails(4000);

            //WriteLine("\nThe car weight is {0} and the car color is {1}", carWeight_1, carColor1);
            //WriteLine("\nThe car weight is {0} and the car color is {1}",carWeight2,carColor2);

            WriteLine("\nThe car weight is {0} and the car color is {1}",carWeight1,carColor1);
            WriteLine("\nThe car weight is {0} and the car color is {1}",carWeight2, carColor2);


            ReadLine();
        }
    }
}
