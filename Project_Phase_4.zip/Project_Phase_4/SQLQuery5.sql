USE [ASPNETCRUD]
GO

SELECT [name]
      ,[city]
      ,[id]
  FROM [dbo].[Person]
GO


