<!DOCTYPE HTML>
<html>
<head>
<meta charset="UTF-8">
<title>Form Example 1</title>

<style>
html{
    
    background-image: url(image2.jpg);
    background-repeat: no-repeat;
    background-size: cover;
    height: 100%;
    }
fieldset{
    background-color:rgb(113, 120, 134);	
    border:3px solid rgb(233,69,0);
    margin:10px 0px 30px 2.5%;
    width:26%;
    color:#262669;	
	
}
#send{
   margin-left: 250px;
   color: blue;
   border-radius: 5px;
    }

.image1{
    
    width:650px;
    height:650px;
    display: inline;
    float: right;
    margin-top: -750px;
    margin-right: 400px;
    border: 3px dotted black;
    border-radius: 50%;
        
    }
</style>

<script>
function formSubmit(){
    
    this.form.submit();
//    console.log(sending);
    
    
}
</script>

</head>

<body>
    


<form id="sending" enctype="multipart/form-data"  action="../my_Projects/Cust_receit.php"  method="post" >

	<fieldset id="custInfo">
        <legend><strong>Candidate Information</strong></legend>
        
        <label for="candName"> Name:</label> 
        <input name="candName" id="candName" />
        <br/>
        <br/>
        <label for="street">Street address:</label>
        <input name="street" id="street" />
        <br/>
        <br/>
        <label for="city">City:</label>
        <input name="city" id="city" />
        <br/>
        <br/>
		<label for="state">State (abbr.):</label>
        <input name="state" id="state" />
        <br/>
        <br/>
        <label for="zip"> Postal code</label>
        <input name="zip" id="zip" />
        <br/>
        <br/>
        <label for="phone"> Phone number:</label> 
        <input name="phone" id="phone" />
        <br/>
        <br/>
        <label for="email">E-mail:</label>
        <input name="email" id="email" />
        <br/>
        <br/>
    
    </fieldset>
    
	<fieldset id="experience">
        <legend><strong>Share Your Experience</strong></legend>
        
        <label for="visitdate">Date of visit:</label>
        <input name="visitdate" id="visitdate" />
        <br/>
        <br/>
        <label for="receipt">Reciept number:</label>
        <input name="receipt" id="receipt" />
        <br/>
        <br/>
    </fieldset>
    
    <fieldset>
        <legend><strong>Provide your previous employers' background</strong></legend>
        
        <label for="company">Company's Name</label>
        <input id="comN" name="company" type="text">
        <br/>
        <br/>
        <label for="department">Department's Name</label>
        <input id="depN" name="department" type="text">
        <br/>
        <br/>
   </fieldset>
    
   <fieldset>
        <legend><strong>Provide your education's background</strong></legend>
        
        <label for="college">College's Name</label>
        <input id="collN" name="college" type="text">
        <br/>
        <br/>
        <label for="yearGraduate">Graduat's Year</label>
        <input id="YearNum" name="yearGraduate" type="number">
        <br/>
        <br/>
   </fieldset>
    <br/>
    <br/>
	<button id="send" type="submit" value="submit" onclick="formSubmit();">submit</button>
    <img class="image1" src="../my_Projects/images.jpg">

</form>

</body>
</html>
