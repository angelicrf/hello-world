<!DOCTYPE html>
<html>
<body>
<h1>Congradulation! here is your confirmation receipt:</h1>
 
    
Welcome to our program 
<?php echo $_POST["candName"]; ?><br><br>
Your street is: <?php echo $_POST["street"]; ?><br><br>
Your city is: <?php echo $_POST["city"]; ?><br><br>
Your state is: <?php echo $_POST["state"]; ?><br><br>
Your zip is: <?php echo $_POST["zip"]; ?><br><br>
Your phone is: <?php echo $_POST["phone"]; ?><br><br>
Your email is: <?php echo $_POST["email"]; ?><br><br>
Your visit date is: <?php echo $_POST["visitdate"]; ?><br><br>
Your company is: <?php echo $_POST["company"]; ?><br><br>
Your department is: <?php echo $_POST["department"]; ?><br><br>
Your college is: <?php echo $_POST["college"]; ?><br><br>
Your year graduated is: <?php echo $_POST["yearGraduate"]; ?><br><br>
Your receipt is: <?php echo $_POST["receipt"]; ?>

</body>
</html>